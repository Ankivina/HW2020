-- Table: public.course_address_time

-- DROP TABLE public.course_address_time;

CREATE TABLE public.course_address_time
(
    id character varying(64) COLLATE pg_catalog."default" NOT NULL,
    course_no character varying(64) COLLATE pg_catalog."default",
    course_name character varying(64) COLLATE pg_catalog."default",
    course_address character varying(64) COLLATE pg_catalog."default",
    day_of_week character varying(8) COLLATE pg_catalog."default",
    course_time character varying(14) COLLATE pg_catalog."default",
    CONSTRAINT course_address_time_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.course_address_time
    OWNER to postgres;