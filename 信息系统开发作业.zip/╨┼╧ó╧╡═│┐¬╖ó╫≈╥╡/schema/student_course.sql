-- Table: public.student_course

-- DROP TABLE public.student_course;

CREATE TABLE public.student_course
(
    student_no integer NOT NULL,
    course_address_time_id character varying(64) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT student_course_pkey PRIMARY KEY (student_no, course_address_time_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.student_course
    OWNER to postgres;