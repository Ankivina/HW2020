import datetime
import time

from aiohttp import web
from dataclasses import asdict
from serv.json_util import json_dumps

from .config import db_block, web_routes


@web_routes.get("/api/course/list")
async def get_student_list(request):
    with db_block() as db:
        db.execute("""
        SELECT id,course_no,course_name , course_address, day_of_week, course_time FROM course_address_time
        """)
        data = list(asdict(r) for r in db)
        
    return web.Response(text=json_dumps(data), content_type="application/json")


@web_routes.get("/api/course/all")
async def get_student_list(request):
    with db_block() as db:
        db.execute("""
        SELECT sn id, no course_no, name course_name FROM public.course;
        """)
        data = list(asdict(r) for r in db)

    return web.Response(text=json_dumps(data), content_type="application/json")


@web_routes.get("/api/course/{course_name:\s+}/{course_address:\s+}")
async def get_course_profile(request):
    course_name = request.match_info.get("course_name")
    course_address = request.match_info.get("course_address")

    with db_block() as db:
        db.execute("""
        SELECT course_name, course_address FROM course_address_time
        WHERE course_name=%(course_name)s and course_address=%(course_address)s
        """, dict(course_name=course_name))
        record = db.fetch_first()

    if record is None:
        return web.HTTPNotFound(text=f"no such student: course_name={course_name}")

    data = asdict(record)
    return web.Response(text=json_dumps(data), content_type="application/json")


@web_routes.post("/api/course/add_add_time")
async def new_student(request):
    course_add_time = await request.json()
    if not course_add_time.get('id'):
        course_add_time['id'] = time.time()

    with db_block() as db:
        db.execute("""
        select name from course where no=%(course_no)s;
        """, course_add_time)
        record = db.fetch_first()

    course_add_time['course_name']=record.name

    with db_block() as db:
        db.execute("""
        INSERT INTO course_address_time (id,course_no,course_name, course_address, day_of_week,course_time)
        VALUES(%(id)s,%(course_no)s, %(course_name)s, %(course_address)s, %(day_of_week)s, %(course_time)s) RETURNING course_name;
        """, course_add_time)
        record = db.fetch_first()

        course_add_time["course_no"] = record.course_name
    
    print(course_add_time)

    return web.Response(text=json_dumps(course_add_time), content_type="application/json")


@web_routes.put("/api/course/update_add_time")
async def update_course(request):

    course_address_time = await request.json()

    id = course_address_time['id']

    with db_block() as db:
        db.execute("""
        select name from course where no=%(course_no)s;
        """, course_address_time)
        record = db.fetch_first()

    course_address_time['course_name'] = record.name

    with db_block() as db:
        db.execute("""
        UPDATE course_address_time SET
            course_no=%(course_no)s, course_name=%(course_name)s, course_address=%(course_address)s, day_of_week=%(day_of_week)s,course_time=%(course_time)s
        WHERE id=%(id)s;
        """, course_address_time)

    return web.Response(text=json_dumps(course_address_time), content_type="application/json")


@web_routes.post("/api/del/course")
async def delete_course(request):
    data = await request.json()
    id=data['id']

    with db_block() as db:
        db.execute("""
        DELETE FROM course_address_time WHERE id=%(id)s;
        """, dict(id=id))

    return web.Response(text="", content_type="text/plain")
