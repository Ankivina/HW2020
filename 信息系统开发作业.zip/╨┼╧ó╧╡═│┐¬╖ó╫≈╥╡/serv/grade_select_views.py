from urllib.parse import urlencode

import psycopg2
from aiohttp import web
from .config import db_block, web_routes, render_html


@web_routes.get("/gradeSelect")
async def view_list_grades(request):
    with db_block() as db:
        db.execute("""
        SELECT sn AS stu_sn, name as stu_name FROM student ORDER BY name
        """)
        students = list(db)

        db.execute("""
        SELECT sn AS cou_sn, name as cou_name FROM course ORDER BY name
        """)
        courses = list(db)

        db.execute("""
        SELECT g.stu_sn, g.cou_sn, 
            s.name as stu_name, 
            c.name as cou_name, 
            g.grade 
        FROM course_grade as g
            INNER JOIN student as s ON g.stu_sn = s.sn
            INNER JOIN course as c  ON g.cou_sn = c.sn
        ORDER BY stu_sn, cou_sn;
        """)

        items = list(db)

    return render_html(request, 'grade_select_list.html',
                       students=students,
                       courses=courses,
                       items=items)


@web_routes.post('/action/grade/select')
async def action_grade_select(request):
    params = await request.post()
    student_no = params.get("stu_sn")
    cou_sn = params.get("cou_sn")

    with db_block() as db:
        db.execute("""
        SELECT sn AS stu_sn, name as stu_name FROM student ORDER BY name
        """)
        students = list(db)

        db.execute("""
        SELECT sn AS cou_sn, name as cou_name FROM course ORDER BY name
        """)
        courses = list(db)

    if student_no is not None and student_no != '':
        with db_block() as db:
            db.execute("""
                SELECT g.stu_sn, g.cou_sn, 
                    s.name as stu_name, 
                    c.name as cou_name, 
                    g.grade 
                FROM course_grade as g
                    INNER JOIN student as s ON g.stu_sn = s.sn
                    INNER JOIN course as c  ON g.cou_sn = c.sn
                where s.sn = %(student_no)s
                ORDER BY stu_sn, cou_sn;
                """ , dict(student_no=student_no))
            grades = list(db)

        return render_html(request, 'grade_select_list.html',
                           students=students,
                           courses=courses,
                           course_no=cou_sn,
                           items=grades)
    if cou_sn is not None and cou_sn != '':
        with db_block() as db:
            db.execute("""
                SELECT g.stu_sn, g.cou_sn, 
                    s.name as stu_name, 
                    c.name as cou_name, 
                    g.grade 
                FROM course_grade as g
                    INNER JOIN student as s ON g.stu_sn = s.sn
                    INNER JOIN course as c  ON g.cou_sn = c.sn
                where c.sn = %(cou_sn)s
                ORDER BY stu_sn, cou_sn;
                """ , dict(cou_sn=cou_sn))
            grades = list(db)

        return render_html(request, 'grade_select_list.html',
                           students=students,
                           courses=courses,
                           items=grades)
    if cou_sn is not None and cou_sn != '' and student_no is not None and student_no != '':
        with db_block() as db:
            db.execute("""
                SELECT g.stu_sn, g.cou_sn, 
                    s.name as stu_name, 
                    c.name as cou_name, 
                    g.grade 
                FROM course_grade as g
                    INNER JOIN student as s ON g.stu_sn = s.sn
                    INNER JOIN course as c  ON g.cou_sn = c.sn
                where s.sn = %(student_no)s and c.sn = %(cou_sn)s
                ORDER BY stu_sn, cou_sn;
                """ , dict(cou_sn=cou_sn,student_no=student_no))
            grades=list(db)

        return render_html(request, 'grade_select_list.html',
                       students=students,
                       courses=courses,
                       items=grades)
    return web.HTTPFound(location="/gradeSelect")
